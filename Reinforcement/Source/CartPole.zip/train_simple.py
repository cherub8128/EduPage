import os, time, torch, webbrowser, threading
import http.server, socketserver
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback, ProgressBarCallback, CallbackList
from stable_baselines3.common.logger import configure
from websocket_env import WebSocketEnv

# --- 중요 설정 ---
# 1. 관찰 공간 (Observation Space) - AI의 '눈'
OBSERVATION_SHAPE = (4,)
# OBSERVATION_SHAPE = (1, 84, 84) # CnnPolicy를 위한 이미지 관찰 예시
# 2. 행동 공간 (Action Space) - AI의 '손'
# ACTION_SPACE_CONFIG = {'type': 'discrete', 'n': 5}
ACTION_SPACE_CONFIG = {'type': 'continuous', 'low': [-2.0], 'high': [2.0]} # 1차원 연속 행동 예시
# ACTION_SPACE_CONFIG = {'type': 'continuous', 'low': [-1.0, -3.0], 'high': [1.0, 3.0]} # 2차원 연속 행동 예시

# -----------------
LOG_DIR, TOTAL_TIMESTEPS, PORT = "training_logs", 1_000_000, 8000
os.makedirs(LOG_DIR, exist_ok=True)

class WebServerThread(threading.Thread):
    def __init__(self, port): super().__init__(); self.port, self.server, self.daemon = port, None, True
    def run(self): self.server = socketserver.TCPServer(("", self.port), http.server.SimpleHTTPRequestHandler); self.server.serve_forever()
    def stop(self):
        if self.server: self.server.shutdown()

class OnnxablePolicy(torch.nn.Module):
    def __init__(self, policy):
        super().__init__()
        self.policy = policy.eval()

    def forward(self, observation: torch.Tensor):
        with torch.no_grad():
            return self.policy._predict(observation, deterministic=True)

def export_to_onnx(model_path, onnx_path, obs_shape=(4,)):
    print(f"\n모델 {model_path}를 ONNX({onnx_path})로 변환합니다...")
    model = PPO.load(model_path, device='cpu')
    onnxable = OnnxablePolicy(model.policy)

    dummy = torch.randn(1, *obs_shape, dtype=torch.float32)   # [1, 4]
    torch.onnx.export(
        onnxable, dummy, onnx_path,
        opset_version=14,
        input_names=["observation"],
        output_names=["action"],
        dynamic_axes={
            "observation": {0: "batch"},
            "action": {0: "batch"},
        }
    )
    print("ONNX 변환 완료.")

def find_latest_run_and_checkpoint():
    if not os.path.isdir(LOG_DIR): return None, None
    runs = sorted([d for d in os.listdir(LOG_DIR) if os.path.isdir(os.path.join(LOG_DIR, d))], reverse=True)
    for run in runs:
        run_path = os.path.join(LOG_DIR, run)
        checkpoints_path = os.path.join(run_path, "checkpoints")
        if not os.path.isdir(checkpoints_path): continue
        checkpoints = [f for f in os.listdir(checkpoints_path) if f.startswith("rl_model_") and f.endswith(".zip")]
        if checkpoints:
            latest_checkpoint = max(checkpoints, key=lambda f: int(f.split("_")[2].replace(".zip", "")))
            return run, os.path.join(checkpoints_path, latest_checkpoint)
    return None, None

def main():
    web_server = WebServerThread(PORT)
    web_server.start()
    time.sleep(1)
    webbrowser.open(f'http://localhost:{PORT}')
    
    latest_run_name, latest_checkpoint = find_latest_run_and_checkpoint()
    
    TENSORBOARD_LOG_NAME = latest_run_name if latest_run_name else f"PPO_{int(time.time())}"
    run_path = os.path.join(LOG_DIR, TENSORBOARD_LOG_NAME)
    
    checkpoint_path = os.path.join(run_path, "checkpoints")
    os.makedirs(checkpoint_path, exist_ok=True)
    
    env = WebSocketEnv(observation_shape=OBSERVATION_SHAPE, action_space_config=ACTION_SPACE_CONFIG)
    custom_logger = configure(run_path, ["stdout", "tensorboard"])
    
    checkpoint_callback = CheckpointCallback(save_freq=20000, save_path=checkpoint_path, name_prefix="rl_model")
    progress_callback = ProgressBarCallback()
    callback_list = CallbackList([checkpoint_callback, progress_callback])
    
    policy_type = "CnnPolicy" if len(OBSERVATION_SHAPE) == 3 else "MlpPolicy"
    
    if latest_checkpoint:
        print(f"체크포인트에서 학습을 재개합니다: {latest_checkpoint}")
        model = PPO.load(latest_checkpoint, env=env, device='auto')
    else:
        print(f"{policy_type} 정책으로 새로운 학습 세션을 시작합니다.")
        model = PPO(policy_type, env, verbose=0, device='auto') # verbose=0 for clean progress bar
        
    model.set_logger(custom_logger)
    final_model_path = ""
    try:
        model.learn(total_timesteps=TOTAL_TIMESTEPS, callback=callback_list, reset_num_timesteps=not bool(latest_checkpoint))
        final_model_path = os.path.join(run_path, "final_model.zip")
        model.save(final_model_path)
        print(f"\n최종 모델 저장 완료: {final_model_path}")
    finally:
        env.close()
        web_server.stop()

    if os.path.exists(final_model_path):
        export_to_onnx(final_model_path, "model.onnx")

if __name__ == '__main__':
    main()